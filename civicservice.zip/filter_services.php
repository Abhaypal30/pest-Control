<?php
// $servername = "localhost";
// $username = "root";
// $password = '';
// $dbname = "pest";

$servername = "localhost";
$username = "a3sptgdk_pest_control";
$password = 'pest_control@123';
$dbname = "a3sptgdk_pest_control";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch posted data
$type = $_POST['type'];
$serviceType = isset($_POST['serviceType']) ? $_POST['serviceType'] : "";
$bhk = isset($_POST['bhk']) ? $_POST['bhk'] : "";
$service = isset($_POST['service']) ? $_POST['service'] : "";

// Construct SQL query based on provided parameters
// Construct SQL query based on provided parameters
// Construct SQL query based on provided parameters
$query = "SELECT * FROM services WHERE type = '$type'";

// Append additional conditions based on provided parameters
if ($type === 'pest-control') {
    // Check if serviceType is empty before adding the condition
    if (!empty($serviceType)) {
        $query .= " AND pest_control = '$serviceType'";
    }
} else if ($type === 'home-cleaning') {
    // Check if serviceType is empty before adding the condition
    if (!empty($serviceType)) {
        $query .= " AND home_cleaning = '$serviceType'";
    }
}
if (!empty($bhk)) {
    $query .= " AND bhk = '$bhk'";
}
if (!empty($service)) {
    $query .= " AND service_type = '$service'";
}

// Limit the result to 2 records
$query .= " ORDER BY id DESC LIMIT 2"; // Limit the result to 2 records


// Execute the query
$result = mysqli_query($conn, $query);

// Check if there are any results
if (mysqli_num_rows($result) > 0) {
    // Loop through results and generate HTML for each service
    while ($row = mysqli_fetch_assoc($result)) {
        // Generate HTML for each service item
        echo '<div class="col-lg-5">';
        echo '<div class="packagebox keypoints recommended">';
        echo '<div class="acc_header">';
        echo '<h2 class="name">' . $row['name'] . '</h2>';
        echo '<div class="headerprice">' . $row['price'] . '</div>';
        echo '</div>';
        echo '<div class="acc_body">';
        echo '<div class="row no-gutters justify-content-center">';
        echo '<div class="col-auto">' . $row['description'] . '</div>';
        echo '</div>';
        echo '<div class="differ_part">';
        echo '<div class="services">' . $row['service_type'] . '</div>';
        echo '<div class="row no-gutters pricerow align-items-center">';
        echo '<div class="col-12"><div class="price">' . $row['payment_mode'] . '</div></div>';
        echo '</div>';
        echo '<div class="row no-gutters btnsrow align-items-center">';
        echo '<div class="col-12">';
        echo '<a href="#info" rel="facebox"><div class="action primary book_now" style="color: black;">Book Now</div></a>';
        echo '</div>';
        echo '<div class="col-12"><div class="last_book">' . $row['last_booking_date'] . '</div></div>';
        echo '</div></div></div></div></div>';
    }
} else {
    echo '<p>No services found</p>' ;
}

// Close the database connection
mysqli_close($conn);
?>
<?php
// Include your CRUD class or any database connection logic here
// Assuming you have already included the necessary files or setup database connection
// $servername = "localhost";
// $username = "root";
// $password = '';
// $dbname = "pest";
// $conn = new mysqli($servername, $username, $password, $dbname);

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// // Fetch posted data
// $type = $_POST['type'];
// $serviceType = isset($_POST['serviceType']) ? $_POST['serviceType'] : "";
// $bhk = isset($_POST['bhk']) ? $_POST['bhk'] : "";
// $service = isset($_POST['service']) ? $_POST['service'] : "";

// // Construct SQL query based on provided parameters
// $query = "SELECT * FROM services WHERE type = '$type'";

// // Append additional conditions based on provided parameters
// if ($type === 'pest-control') {
//     // Check if serviceType is empty before adding the condition
//     if (!empty($serviceType)) {
//         $query .= " AND pest_control = '$serviceType'";
//     }
// } else if ($type === 'home-cleaning') {
//     // Check if serviceType is empty before adding the condition
//     if (!empty($serviceType)) {
//         $query .= " AND home_cleaning = '$serviceType'";
//     }
// }
// if (!empty($bhk)) {
//     $query .= " AND bhk = '$bhk'";
// }
// if (!empty($service)) {
//     $query .= " AND service_type = '$service'";
// }

// // Execute the query
// $result = mysqli_query($conn, $query);

// // Check if there are any results
// if (mysqli_num_rows($result) > 0) {
//     // Check the number of records fetched
//     if (mysqli_num_rows($result) > 1) {
//         // Multiple records fetched, use .packagebox class
//         $cardClass = 'packagebox col-lg-4';
//     } else {
//         // Only one record fetched, create a new class and fetch its CSS
//         $cardClass = 'single-packagebox col-lg-4';
//     }

//     // Loop through results and generate HTML for each service
//     while ($row = mysqli_fetch_assoc($result)) {
//         // Generate HTML for each service item
//         echo '<div class="' . $cardClass . ' keypoints recommended">';
//         echo '<div class="acc_header">';
//         echo '<h2 class="name">' . $row['name'] . '</h2>';
//         echo '<div class="headerprice">' . $row['price'] . '</div>';
//         echo '</div>';
//         echo '<div class="acc_body">';
//         echo '<div class="row no-gutters justify-content-center">';
//         echo '<div class="col-auto">' . $row['description'] . '</div>';
//         echo '</div>';
//         echo '<div class="differ_part">';
//         echo '<div class="services">' . $row['service_type'] . '</div>';
//         echo '<div class="row no-gutters pricerow align-items-center">';
//         echo '<div class="col-12"><div class="price">' . $row['payment_mode'] . '</div></div>';
//         echo '</div>';
//         echo '<div class="row no-gutters btnsrow align-items-center">';
//         echo '<div class="col-12">';
//         echo '<a href="#info" rel="facebox"><div class="action primary book_now">Book Now</div></a>';
//         echo '</div>';
//         echo '<div class="col-12"><div class="last_book">' . $row['last_booking_date'] . '</div></div>';
//         echo '</div></div></div></div>';
//     }
// } else {
//     echo '<p>No services found</p>';
// }

// // Close the database connection
// mysqli_close($conn);
?>
