<?php
session_start();
require"connect.php";
error_reporting(1);

?>
