<?php
// --- PART 1 ---
ob_start();
?>
<div class="serv_page_txt">
    <h2 class="span_ele pst_toppadder20">Bedbug Control</h2>
    <p class="pst_toppadder10">
        Our bedbug control uses advanced odorless and safe insecticides. Effective for residential and commercial use.
    </p>
    <h2 class="span_ele pst_toppadder20">Why choose us?</h2>
    <p class="pst_toppadder10">3-step eradication | Eco-safe treatment | 24x7 support</p>
</div>

<div class="serv_page_txt section-top">
    <h2 class="span_ele pst_toppadder20">Think Your Bed Belongs Only to You? Think Again!</h2>
    <p class="pst_toppadder10">
        If you believe your bed is exclusively for you and your family, you might be in for a surprise! Sleepless nights caused by tiny, creepy crawlies—bed bugs—can quickly turn your cozy space into a nightmare.
        The moment you spot any signs of bed bugs—whether on your mattress, bedding, curtains, or clothes—it’s the right time to call Civic Pest Control for a professional bed bug treatment.
    </p>

    <h3 class="pst_toppadder20">Our Bed Bug Service Packages</h3>

    <h4>🟢 BBMS – Standard (2 Visits)</h4>
    <ul class="black-dot-list">
        <li>Identification of common bed bug hideouts</li>
        <li>CIB-approved, mild odor spray treatment</li>
        <li>1st Visit – Day 1</li>
        <li>2nd Visit – Day 16</li>
        <li>Technicians – 1 expert per visit</li>
    </ul>

    <h4>🔵 BBMS - Pro (4 Visits)</h4>
    <ul class="black-dot-list">
        <li>All BBMS Lite steps plus:</li>
        <li>Close monitoring of bed bug egg hatching</li>
        <li>Ensures long-term elimination</li>
        <li>Visits on: Day 1, Day 16, Day 46, Day 76</li>
        <li>Technicians – 1 expert per visit</li>
    </ul>
</div>
<?php
$service_parts['bedbug_control']['part1'] = ob_get_clean();

// --- PART 2 ---
ob_start();
?>
<div class="serv_page_txt section-bottom">
    <h3 class="span_ele pst_toppadder20">Why Choose Civic Pest Control?</h3>
    <ul class="black-dot-list">
        <li>Serving homes & businesses since 2011</li>
        <li>CIB-approved and pet-safe chemicals</li>
        <li>Trained and experienced technicians</li>
        <li>Use of advanced tools and modern spray techniques</li>
        <li>Focus on root-cause elimination and full relief</li>
        <li>Free follow-up for any post-service complaint</li>
        <li>Experience with 2000+ homes and 100+ societies in Mumbai, Thane & Navi Mumbai</li>
    </ul>

    <h3 class="pst_toppadder20">When Should You Book a Bed Bug Service?</h3>
    <ul class="black-dot-list">
        <li>Reddish or rusty stains on your bedsheets or mattress</li>
        <li>Tiny white eggs or shed skins in bedding or corners</li>
        <li>Itchy bites or crawling bugs spotted on the bed</li>
        <li>Disturbed sleep with unexplained skin irritations</li>
    </ul>

    <h3 class="pst_toppadder20">How We Work – The Civic Approach</h3>
    <ol class="pst_toppadder10">
        <li><strong>Inspection:</strong> Our technician carefully inspects bedding, curtains, upholstery, and cracks to locate bed bug activity.</li>
        <li><strong>Spray Injection:</strong> A targeted application of safe, mild odor chemicals to affected areas for effective elimination.</li>
        <li><strong>Follow-Up Check:</strong> A re-visit is scheduled to check the effectiveness and prevent recurrence.</li>
    </ol>

    <p class="pst_toppadder10"><strong>Service Duration:</strong><br>
        Each visit typically lasts 45 minutes to 1 hour, depending on the level of infestation and the size of the area.
    </p>

    <p class="pst_toppadder10"><strong>Pricing:</strong><br>
        The cost of treatment depends on the selected package and the extent of infestation. Contact us for a custom quote today!
    </p>
</div>
<?php
$service_parts['bedbug_control']['part2'] = ob_get_clean();
?>
