<?php
// --- PART 1 ---
ob_start();
?>
<div class="serv_page_txt">
    <h2 class="span_ele pst_toppadder20">Termite Control Treatment (Post-Construction)</h2>
    <p class="pst_toppadder10">
        Say goodbye to hidden termite colonies and protect your home with Civic Pest Control’s scientific termite treatment method.
    </p>

    <h3 class="pst_toppadder20">🛠️ Our 3-Step Method: Drill – Fill – Seal</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li><strong>DRILL:</strong> Holes of 1.2 cm diameter are drilled at the wall-skirt level, spaced at 1-foot intervals.</li>
        <li><strong>FILL:</strong> A specialized anti-termite chemical (Termicide) is injected into each hole to eliminate termites and destroy the colony.</li>
        <li><strong>SEAL:</strong> The holes are sealed with white cement to restore aesthetics.</li>
    </ul>

    <h3 class="pst_toppadder20">✅ Available Packages</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>Termite Treatment – 1 Year Warranty</li>
        <li>Termite Treatment – 2 Year Warranty</li>
    </ul>

    <h3 class="pst_toppadder20">🔄 Service Plan Details</h3>
    <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
        <thead>
            <tr>
                <th>Plan</th>
                <th>Service Cycle</th>
                <th>Audit Services</th>
                <th>Manpower</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1 Year AMC</td>
                <td>1 Main Service</td>
                <td>1 Audit (4th Month)</td>
                <td>2 for main, 1 for audit</td>
            </tr>
            <tr>
                <td>2 Year AMC</td>
                <td>1 Main Service</td>
                <td>2 Audits (4th & 13th Month)</td>
                <td>2 for main, 1 for audits</td>
            </tr>
        </tbody>
    </table>
</div>
<?php
$service_parts['termite_control']['part1'] = ob_get_clean();


// --- PART 2 ---
ob_start();
?>
<div class="serv_page_txt section-bottom">
    <h3 class="span_ele pst_toppadder20">🏆 Why Choose Civic Pest Control?</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>🏠 Free Inspection and Consultation</li>
        <li>✅ Warranty-Backed Services</li>
        <li>🔁 FREE Complaint Visits During Warranty</li>
        <li>🧱 Advanced Core Cutter Technique (for wall-to-furniture joints)</li>
        <li>🧪 Scientific Solutions – Less Chemical, More Efficiency</li>
        <li>👷 Certified & Trained In-House Technicians</li>
        <li>🧴 Odourless, Safe & Long-Lasting Treatment</li>
        <li>📜 HACCP Certified Pest Control Provider</li>
        <li>🕰️ Over a Decade of Service Excellence Since 2011</li>
    </ul>

    <h3 class="pst_toppadder20">📌 Terms & Conditions</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>🕒 Service effectiveness begins 21 days after application.</li>
        <li>📅 The scheduled service must be availed within 30 days of booking.</li>
    </ul>
</div>
<?php
$service_parts['termite_control']['part2'] = ob_get_clean();
?>
