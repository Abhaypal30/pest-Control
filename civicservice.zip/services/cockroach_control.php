<?php
// --- PART 1 ---
ob_start();
?>
<div class="serv_page_txt">
    <h2 class="span_ele pst_toppadder20">Cockroach Pest Control</h2>
    <p class="pst_toppadder10">
        Comprehensive Cockroach Control Treatment by Civic Pest Control
    </p>
    <p class="pst_toppadder10">
        We offer an effective Standard Cockroach Control Treatment using European-approved gel and spray formulations to keep your home cockroach-free and hygienic.
    </p>

    <h3 class="pst_toppadder20">Our Standard Cockroach Control Treatment Includes:</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>Gel Baiting & Spray Treatment targeting cockroaches in cabinets, cracks, and visible areas</li>
        <li>Use of safe, eco-friendly products to ensure the safety of your family and pets</li>
        <li>Expert technicians with years of experience delivering hassle-free pest control</li>
        <li>Sealing of small cracks and crevices to deny cockroach shelter</li>
        <li>Enzyme-based drain cleaning to break down organic matter and prevent cockroach breeding</li>
    </ul>

    <h3 class="pst_toppadder20">Service Details</h3>
    <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
        <thead>
            <tr>
                <th>Service Type</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Standard Cockroach Control</td>
                <td>1X treatment using European-approved gel & spray</td>
            </tr>
            <tr>
                <td>AMC Options</td>
                <td>
                    1 Year AMC – 3 Services (1 every 4 months)<br>
                    2 Year AMC – 6 Services (1 every 4 months)
                </td>
            </tr>
            <tr>
                <td>Manpower</td>
                <td>1 technician per service</td>
            </tr>
        </tbody>
    </table>
</div>
<?php
$service_parts['cockroach_control']['part1'] = ob_get_clean();


// --- PART 2 ---
ob_start();
?>
<div class="serv_page_txt section-bottom">
    <h3 class="span_ele pst_toppadder20">Why Choose Civic Pest Control?</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>Over 14 years of expertise in pest control services</li>
        <li>Minimized use of synthetic chemicals for your family’s safety</li>
        <li>Scientifically designed service interventions for long-lasting results</li>
        <li>No need to empty your kitchen during treatment</li>
        <li>Flexible timing — services can be conducted at any time of the day</li>
        <li>Warranty-backed AMC contracts for peace of mind</li>
        <li>Services delivered by experienced hygiene experts</li>
    </ul>

    <h3 class="pst_toppadder20">When to Book a Cockroach Control Service?</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>Cockroaches or baby cockroaches crawling in kitchen cabinets, bathrooms, or under beds</li>
        <li>Cockroach wings, droppings, or dead cockroaches around your home</li>
        <li>A foul, persistent odour growing stronger daily</li>
        <li>Water leakage or dampness in kitchen, bathroom, or balcony</li>
        <li>Frequent illnesses due to suspected food contamination</li>
    </ul>

    <h3 class="pst_toppadder20">How Does the Civic Pest Control Team Work?</h3>
    <p class="pst_toppadder10">
        Our trained technicians follow these steps for effective cockroach control:
    </p>
    <p class="pst_toppadder10">
        <strong>Gel and Spray Treatment:</strong> Application of odorless gel in closed areas such as cabinets and drawers, and spray in open areas like bathrooms and balconies.
    </p>

    <h3 class="pst_toppadder20">Duration and Cost</h3>
    <ul class="black-dot-list pst_toppadder10">
        <li>Each cockroach control service takes approximately 30-40 minutes depending on the area and treatment type.</li>
        <li>Pricing depends on the area to be treated and the number of services chosen. We offer competitive rates with quality assurance.</li>
    </ul>

    <h3 class="pst_toppadder20">How to Book a Cockroach Control Service?</h3>
    <ol class="pst_toppadder10">
        <li>Call us directly at <strong>9022222923 / 9320402004</strong></li>
        <li>Email us at <strong>info@civicpestcontrol.com</strong></li>
        <li>Visit our website: <a href="https://www.civicpestcontrol.com" target="_blank">www.civicpestcontrol.com</a> and fill out the booking form</li>
        <li>Choose your preferred cockroach control treatment and schedule a service at your convenience</li>
    </ol>

    <p class="pst_toppadder10"><strong>Welcome the guest, not the pest!</strong><br>
        Trust Civic Pest Control for a safe, clean, and pest-free home.
    </p>
</div>
<?php
$service_parts['cockroach_control']['part2'] = ob_get_clean();
?>
